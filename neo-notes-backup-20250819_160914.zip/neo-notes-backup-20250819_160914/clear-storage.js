// Clear localStorage for fresh start
console.log('Clearing Neo Notes storage...');
localStorage.clear();
console.log('✅ Storage cleared');
window.location.reload();