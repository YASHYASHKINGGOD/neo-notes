# planning.md (Milestone N)
- Feature: <name>
- Approach summary
- Components to touch
- Test plan (unit/integration/e2e)
- Rollout/guardrails
