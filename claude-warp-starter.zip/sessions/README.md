Place session logs here using the SESSION_TEMPLATE.md.
