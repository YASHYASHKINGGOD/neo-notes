# DESIGN.md
## Problem & Goals
## Non-Goals
## High-Level Architecture (diagram/bullets)
## Data Model / APIs
## Key Decisions & Tradeoffs
## Risks & Mitigations
## Observability (logs/metrics/debug toggles)
