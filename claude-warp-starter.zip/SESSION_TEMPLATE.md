# SESSION-YYYY-MM-DD

**Owner:** Claude / Warp  
**Scope:** <feature or bug>  
**Related tasks:** #<id> …  

## Plan for this session
- [ ] Step 1 …
- [ ] Step 2 …
- [ ] Exit criteria: …

## Commands executed
```bash
# exact commands
make setup
make check
make start
```
<copy error logs or outputs here>

## Changes
- Files modified/created:
  - `src/...`
  - `tests/...`

## Decisions
- <record any decisions or trade-offs>

## Next steps
- [ ] <carryover task>
- [ ] <doc update needed>

